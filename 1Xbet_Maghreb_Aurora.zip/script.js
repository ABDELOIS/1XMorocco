// Daily opening hours: 10:00–00:00 Morocco time (Africa/Casablanca).
const hoursOverlay=document.getElementById('hoursOverlay');
function isServiceOpenMorocco(){
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Africa/Casablanca',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date());
 const hour=Number(parts.find(p=>p.type==='hour')?.value??0);
 return hour>=10 && hour<24;
}
function updateOpeningStatus(){
 const open=isServiceOpenMorocco();
 hoursOverlay?.classList.toggle('hidden',open);
 document.body.classList.toggle('hours-closed',!open);
 if(!open){wrap?.classList.add('hidden');choices?.classList.add('hidden');}
}


const wrap=document.getElementById('formwrap');
const form=document.getElementById('requestForm');
const choices=document.getElementById('sendchoices');
let current='deposit';
const currency=document.getElementById('currency');
function updateWithdrawAddress(){
 document.getElementById('withdrawAddress').classList.toggle('hidden',current!=='withdraw');
 document.getElementById('withdrawStreet').textContent=currency.value==='USD'?'ABDEL CASH':'ABDEL SERVICE';
}
currency.addEventListener('change',updateWithdrawAddress);
const brandHome=document.querySelector('.brand');
brandHome?.addEventListener('click',e=>{e.preventDefault();wrap.classList.add('hidden');choices.classList.add('hidden');form.classList.remove('hidden');window.scrollTo({top:0,behavior:'smooth'});});
document.querySelectorAll('[data-open]').forEach(b=>b.addEventListener('click',()=>openForm(b.dataset.open)));
const bankSelect=document.getElementById('bankSelect');
const bankDetails=document.getElementById('bankDetails');
const bankAccountName=document.getElementById('bankAccountName');
const bankAccountNumber=document.getElementById('bankAccountNumber');
const bankNumberLabel=document.getElementById('bankNumberLabel');
const copyBtn=document.getElementById('copyBankAccount');
const bankData={
 'Barid Bank':{name:'ABDEL SERVICE',number:'6580483',label:'رقم الحساب'},
 'CIH Bank':{name:'ABDEL SERVICE',number:'4965013211026100',label:'رقم الحساب'},
 'Attijari Bank':{name:'ABDEL SERVICE',number:'007391000651330040054145',label:'رقم الحساب'},
 'Cash Plus':{name:'ABDEL SERVICE',number:'0600606086 / 0659575078',label:'أرقام Cash Plus'}
};
function updateBankDetails(){
 const data=bankData[bankSelect.value];
 bankDetails.classList.toggle('hidden',!data);
 if(!data){bankAccountName.textContent='—';bankAccountNumber.textContent='—';bankNumberLabel.textContent='رقم الحساب:';copyBtn.disabled=true;return;}
 bankAccountName.textContent=data.name;bankAccountNumber.textContent=data.number;bankNumberLabel.textContent=data.label+':';copyBtn.disabled=false;
 copyBtn.onclick=async()=>{try{await navigator.clipboard.writeText(data.number);copyBtn.textContent='تم النسخ ✓';setTimeout(()=>copyBtn.textContent='نسخ الرقم',1800);}catch(e){alert(data.label+': '+data.number);}};
}
bankSelect.addEventListener('change',updateBankDetails);
function openForm(type){
 if(!isServiceOpenMorocco()){updateOpeningStatus();return;}
 current=type;wrap.classList.remove('hidden');choices.classList.add('hidden');form.classList.remove('hidden');form.reset();
 document.getElementById('type').value=type;
 document.getElementById('formtitle').textContent=type==='deposit'?'طلب الشحن':'طلب السحب';
 document.getElementById('formtag').textContent=type==='deposit'?'شحن الرصيد':'سحب الرصيد';
 document.getElementById('bankField').classList.toggle('hidden',type==='withdraw');
 document.getElementById('codeField').classList.toggle('hidden',type==='deposit');
 document.getElementById('accountField').classList.toggle('hidden',type==='deposit');
 document.getElementById('receiptField').classList.toggle('hidden',type==='withdraw');
 bankSelect.required=type==='deposit';document.getElementById('withdrawBank').required=type==='withdraw';
 document.querySelector('[name="account"]').required=type==='withdraw';document.querySelector('[name="code"]').required=type==='withdraw';
 document.querySelector('[name="proof"]').required=false;
 bankSelect.value='';updateBankDetails();updateWithdrawAddress();
 wrap.scrollIntoView({behavior:'smooth',block:'start'});
}
document.getElementById('closeForm').onclick=()=>wrap.classList.add('hidden');
document.getElementById('editAgain').onclick=()=>{choices.classList.add('hidden');form.classList.remove('hidden');};
form.addEventListener('submit',e=>{
 e.preventDefault();const fd=new FormData(form);
 let lines=['Charge 1Xbet Morocco — '+(current==='deposit'?'طلب شحن':'طلب سحب'),'ID 1Xbet: '+fd.get('id'),'المبلغ: '+fd.get('amount'),'العملة: '+fd.get('currency')];
 if(current==='deposit')lines.push('البنك: '+fd.get('bank'));
 else lines.push('كود السحب: '+fd.get('code'),'البنك: '+fd.get('withdrawBank'),'حسابك: '+fd.get('account'));
 const waLines=[...lines],tgLines=[...lines];
 if(current==='deposit'){waLines.push('صيفط لي الوصل هنا فالواتساب');tgLines.push('صيفط لي الوصل هنا فالتليغرام');}
 document.getElementById('wa').href='https://wa.me/212600606086?text='+encodeURIComponent(waLines.join('\n'));
 document.getElementById('tg').href='https://t.me/Best_Service0?text='+encodeURIComponent(tgLines.join('\n'));
 form.classList.add('hidden');choices.classList.remove('hidden');
});
document.addEventListener('copy',e=>{const allowed=e.target&&e.target.closest&&e.target.closest('#copyBankAccount');if(!allowed)e.preventDefault();});
document.addEventListener('cut',e=>e.preventDefault());

updateOpeningStatus();
setInterval(updateOpeningStatus,60000);
